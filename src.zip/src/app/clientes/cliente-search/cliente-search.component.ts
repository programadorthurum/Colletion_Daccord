import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cliente-search',
  templateUrl: './cliente-search.component.html',
  styleUrls: ['./cliente-search.component.css']
})
export class ClienteSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
