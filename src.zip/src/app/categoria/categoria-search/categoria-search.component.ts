import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categoria-search',
  templateUrl: './categoria-search.component.html',
  styleUrls: ['./categoria-search.component.css']
})
export class CategoriaSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
