export class Cliente {
    id: number;
    nome: string;
    cpf: string;
    email: string;
    dataNascimento: Date;
    sexo: string;
    nomeSocial: string;
    apelido: string;
    telefone: string;

  }