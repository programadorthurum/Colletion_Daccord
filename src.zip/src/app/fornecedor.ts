export class Fornecedor {
    id: number;
    nome: string;
    telefone: string;
    cnpj: string;
    email: string;
}