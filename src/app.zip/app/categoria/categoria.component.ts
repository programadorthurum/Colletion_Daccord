import { Component, OnInit } from '@angular/core';
import { Categoria } from '../categoria';
import { CategoriaService } from '../categoria.service';

@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.component.html',
  styleUrls: ['./categoria.component.css']
})
export class CategoriaComponent implements OnInit {
  categoria: Categoria[];
 
  constructor(private categoriaService: CategoriaService) { }

  ngOnInit(): void {
    this.getCategorias();
  }

  getCategorias(): void {
    this.categoriaService.getCategorias()
    .subscribe(categorias => this.categoria = categorias);
  }

  add(nome: string): void {
    nome = nome.trim();
    if (!nome) { return; }
    this.categoriaService.addCategoria({ nome } as Categoria)
      .subscribe(categoria => {
        this.categoria.push(categoria);
      });
  }

  delete(categoria: Categoria): void {
    this.categoria = this.categoria.filter(h => h !== categoria);
    this.categoriaService.deleteCategoria(categoria).subscribe();
  }

}
