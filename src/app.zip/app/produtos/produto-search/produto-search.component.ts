import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-produto-search',
  templateUrl: './produto-search.component.html',
  styleUrls: ['./produto-search.component.css']
})
export class ProdutoSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
