import { NgModule } from '@angular/core';
import { Routes, RouterModule  } from '@angular/router';
import { ClientesComponent } from './clientes/clientes.component';
import { CategoriaComponent } from './categoria/categoria.component';
import { ProdutosComponent } from './produtos/produtos.component';
import { ProdutoCreateComponent } from './produtos/produto-create/produto-create.component';
import { ProdutoListarComponent } from './produtos/produto-listar/produto-listar.component';
import { HomeComponent } from './views/home/home.component';

const routes: Routes = [

  //{ path: '', redirectTo: '/home', pathMatch: 'full' },

  { path:'',
    component: HomeComponent
  },
  { path: "produto",
  component: ProdutosComponent
  },
  
  { path: "produto/create",
  component: ProdutoCreateComponent
  },
  { path: "produto/listar",
  component: ProdutoListarComponent
  },
  { path: 'clientes', component: ClientesComponent },
  { path: 'categoria', component: CategoriaComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}


