export interface Cliente {
    id?: number;
    name?: string;
    cpf: string;
    nome: string;
    email: string;
    dataNascimento: Date;
    sexo: string;
    nomeSocial: string;
    apelido: string;
    telefone: string;

  }