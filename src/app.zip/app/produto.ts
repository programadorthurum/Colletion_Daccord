export class Produto{
     id: number;
	 nome: String;
	 descricao: String;
	 preco_unitario: number;
	 unidade: number;
}