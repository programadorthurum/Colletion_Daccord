package com.daccord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackDaccordPortoApplicationTests {

	@Test
	void contextLoads() {
	}

}
