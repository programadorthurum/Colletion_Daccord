package com.daccord;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackDaccordPortoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackDaccordPortoApplication.class, args);
	}

}
